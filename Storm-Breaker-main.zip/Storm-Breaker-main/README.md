<h1 align="center">
  <br>
  <a href="https://github.com/ultrasecurity/Storm-Breaker"><img src="http://dl.sabzlearn.ir/demo/storm/1demo.png" alt="Darkside"></a>

</h1>

<h4 align="center">A tool with attractive capabilities</h4>

<p align="center">
  <a href="http://python.org">
    <img src="https://img.shields.io/badge/python-v3-blue">
  </a>
  <a href="https://php.net">
    <img src="https://img.shields.io/badge/php-7.4.4-green"
         alt="php">
  </a>

  <a href="https://www.microsoft.com/de-de/">
    <img src="https://img.shields.io/badge/platform-Linux-red">
  </a>
</p>

![demo](http://dl.sabzlearn.ir/demo/storm/cu-demo.PNG)

### Features:

- Get Device Information Without Any Permissions
- Access Location [SMARTPHONES]
- Os Password Grabber [WIN-10]
- Access Webcam
- Access Microphone

![save demo](http://dl.sabzlearn.ir/demo/storm/loc-demo.PNG)


### Operating Systems Tested

- Kali Linux 2020

### Installation On Kali Linux


```bash
$ git clone https://github.com/ultrasecurity/Storm-Breaker
$ cd Storm-Breaker
$ sudo bash linux-installer.sh
$ python3 -m pip install -r requirments.txt
$ sudo python3 Storm-Breaker.py
```
